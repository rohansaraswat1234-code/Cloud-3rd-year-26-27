# Practice Examination 1

**Student Name:** Raja Saraswat  
**Roll Number:** 22515990001  
**Subject:** Application Build and Release Automation Lab (BCSE1522)

This folder contains the completed Linux and Git practical work for the Online Course Registration System.

The project includes the student information file, course search module, command record, and backup copy.
